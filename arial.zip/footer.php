       <footer class="footer text-center">
           © <script>
               document.write(new Date().getFullYear())
           </script> Chasedei Kaduri <span class="d-none d-sm-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> by Jetnetix.</span>
       </footer>
       </div>
       <!-- end main content-->

       </div>
       <!-- END layout-wrapper -->


       <!-- Right bar overlay-->
       <div class="rightbar-overlay"></div>


       <!-- JAVASCRIPT -->
       
       <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
       <script src="assets/libs/metismenu/metisMenu.min.js"></script>
       <script src="assets/libs/simplebar/simplebar.min.js"></script>
       <script src="assets/libs/node-waves/waves.min.js"></script>


       <script src="assets/libs/morris.js/morris.min.js"></script>
       <script src="assets/libs/raphael/raphael.min.js"></script>


       <script src="assets/libs/peity/jquery.peity.min.js"></script>

       <script src="assets/js/pages/dashboard.init.js"></script>

       <script src="assets/js/app.js"></script>

       <!-- Required datatable js -->
       <script src="assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
       <script src="assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

       <!-- Datatable init js -->
       <script src="assets/js/pages/datatables.init.js"></script>

       <!-- mobi scroll -->
       <script src="assets/js/mobiscroll.javascript.min.js"></script>

       <!-- select2 -->
       <script src="assets/libs/select2/js/select2.min.js"></script>
       <script src="assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
       <script src="assets/libs/spectrum-colorpicker2/spectrum.min.js"></script>
       <script src="assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
       <script src="assets/libs/admin-resources/bootstrap-filestyle/bootstrap-filestyle.min.js"></script>
       <script src="assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>

       <script src="assets/js/pages/form-advanced.init.js"></script>
 <!-- date range picker -->
       <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script> -->
       <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
       <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
       

       <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjs/10.6.4/math.js" integrity="sha512-BbVEDjbqdN3Eow8+empLMrJlxXRj5nEitiCAK5A1pUr66+jLVejo3PmjIaucRnjlB0P9R3rBUs3g5jXc8ti+fQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjs/10.6.4/math.min.js" integrity="sha512-iphNRh6dPbeuPGIrQbCdbBF/qcqadKWLa35YPVfMZMHBSI6PLJh1om2xCTWhpVpmUyb4IvVS9iYnnYMkleVXLA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
       <!--C3 Chart-->
       <script src="assets/libs/d3/d3.min.js"></script>
       <script src="assets/libs/c3/c3.min.js"></script>

       <!-- Init js -->
       <script src="assets/js/pages/c3-chart.init.js"></script>

       </body>

       </html>
<?php require_once('header.php') ?>

<style>
    .lock{
      display: none;
    }
</style>
<div class="page-content">
    <div class="container-fluid">

        <div class="card p-3">

            <h4 class="mt-0 header-title mb-0 text-center">Chasedei Kaduri Jweish Food Bank</h4>
        </div>



        <div class="row">
            <div class="col-xl-4 col-md-6">

                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Change quantity of item before scanning</h4>

                        <div>

                            <table id="calcu">
                                <tr>
                                    <td colspan="3"><input type="text" id="result" placeholder="1"></td>
                                    <!-- clr() function will call clr to clear all value -->

                                </tr>
                                <tr>
                                    <!-- create button and assign value to each button -->
                                    <!-- dis("1") will call function dis to display value -->
                                    <td><input type="button" value="1" onclick="dis('1')" onkeydown="myFunction(event)"> </td>
                                    <td><input type="button" value="2" onclick="dis('2')" onkeydown="myFunction(event)"> </td>
                                    <td><input type="button" value="3" onclick="dis('3')" onkeydown="myFunction(event)"> </td>
                                    <!-- <td><input type="button" value="/" onclick="dis('/')" onkeydown="myFunction(event)"> </td> -->
                                </tr>
                                <tr>
                                    <td><input type="button" value="4" onclick="dis('4')" onkeydown="myFunction(event)"> </td>
                                    <td><input type="button" value="5" onclick="dis('5')" onkeydown="myFunction(event)"> </td>
                                    <td><input type="button" value="6" onclick="dis('6')" onkeydown="myFunction(event)"> </td>

                                </tr>
                                <tr>
                                    <td><input type="button" value="7" onclick="dis('7')" onkeydown="myFunction(event)"> </td>
                                    <td><input type="button" value="8" onclick="dis('8')" onkeydown="myFunction(event)"> </td>
                                    <td><input type="button" value="9" onclick="dis('9')" onkeydown="myFunction(event)"> </td>

                                </tr>
                                <tr>
                                    

                                    <!-- solve function call function solve to evaluate value -->
                                    <!-- <td><input type="button" value="-" onclick="dis('-')" onkeydown="myFunction(event)"> </td> -->
                                    <td><input type="button" value="c" onclick="clr()" /> </td>
                                    <td><input type="button" value="0" onclick="dis('0')" onkeydown="myFunction(event)"> </td>
                                    <td><input type="button" value="+" onclick="dis('+')" onkeydown="myFunction(event)"> </td>

                                </tr>
                                <!-- <tr>
                                    <td><input type="button" value="*" onclick="dis('*')" onkeydown="myFunction(event)"> </td>
                                    <td><input type="button" value="c" onclick="clr()" /> </td>

                                    <td><input type="button" value="=" onclick="solve()"> </td>

                                </tr> -->
                            </table>


                            </ul>

                        </div>

                    </div>
                </div>

            </div>

            <div class="col-xl-4 col-md-6">
                <div class="card mini-stats">
                    <div class="p-4 mini-stats-content">

                    </div>
                    <div class="mx-3">
                        <div class="card mb-0 border p-3 mini-stats-desc">
                            <div class="d-flex align-items-center justify-content-between">
                                <div>
                                <h6 class="mt-0 mb-3">item location</h6>
                                </div>
                                <div>
                                <input type="text" class="form-control" placeholder="Exp:A16">
                                </div>
                                 
                            </div>
                            <!-- <p class="text-muted mb-0">Sed ut perspiciatis unde iste</p> -->
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">item scanned</h4>

                        <div class="p-2">

                            <div class="no-event d-flex align-center flex-direction" style="height:285px">
                                <img src="assets/images/get.jpeg" class="img-responsive w-230 m-auto mt-3" alt="">
                                <p class="font-bold text-center flex-2 mt-4 font-bold">Getfilte Fish <br>

                                </p>

                            </div>
                        </div>

                    </div>
                </div>
                <div class="card mini-stats">
                    <div class="p-4 mini-stats-content">

                    </div>
                    <div class="mx-3">
                        <div class="card mb-0 border p-3 mini-stats-desc">
                        <div class="d-flex align-items-center justify-content-between">
                                <div>
                                <h6 class="mt-0 mb-3">Barcode Scanned</h6>
                                </div>
                                <div>
                                <input type="text" class="form-control" placeholder="Exp:000988756644">
                                </div>
                                 
                            </div>    
                            
                        </div>
                        
                    </div>
                </div>
            </div>

            <div class="col-xl-4">
                <div class="card">
                    <div class="card-body">
                        <h4 class="mt-0 header-title">Recent scan</h4>

                        <div class="p-2 scan">
                            <div class="table-responsive">
                                <table class="table table-bordered mb-0">
                                    <thead>
                                        <tr>

                                            <th>Product</th>
                                            <th>Barcode</th>
                                            <th>Quantity</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>

                                            <td>Meal Supplement</td>
                                            <td>34325254554363</td>
                                            <td>2</td>
                                        </tr>
                                        <tr>

                                            <td>Meal Supplement</td>
                                            <td>34325254554363</td>
                                            <td>2</td>
                                        </tr>
                                        <tr>

                                            <td>Meal Supplement</td>
                                            <td>34325254554363</td>
                                            <td>1</td>
                                        </tr>
                                        <tr>

                                            <td>Potato pancake</td>
                                            <td>34325254554363</td>
                                            <td>1</td>
                                        </tr>
                                        <tr>

                                            <td>Potato pancake</td>
                                            <td>34325254554363</td>
                                            <td>1</td>
                                        </tr>
                                        <tr>

                                            <td>Getfilte Fish</td>
                                            <td>34325254554363</td>
                                            <td>1</td>
                                        </tr>
                                        <tr>

                                            <td>Getfilte Fish</td>
                                            <td>34325254554363</td>
                                            <td>1</td>
                                        </tr>
                                        <tr>

                                            <td>Getfilte Fish</td>
                                            <td>34325254554363</td>
                                            <td>1</td>
                                        </tr>
                                        <tr>

                                            <td>Potato pancake</td>
                                            <td>34325254554363</td>
                                            <td>1</td>
                                        </tr>


                                    </tbody>
                                </table>
                            </div>

                        </div>

                    </div>
                </div>
                <div class="card mini-stats">
                    <div class="p-4 mini-stats-content">

                    </div>
                    <div class="mx-3">
                        <div class="card mb-0 border p-3 mini-stats-desc">
                            <div class="d-flex justify-content-center">
                            <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target=".bs-example-modal-lg">Submit </a>
                            <a href="#" class="btn btn-danger  mar-left-1" data-bs-toggle="modal" data-bs-target=".bs-example-modal-lg2">  Delete</a>
                            <a href="#" class="btn btn-pink  mar-left-1" data-bs-toggle="modal" data-bs-target=".bs-example-modal-lg3">Switch To Category Editor</a> 
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->


    </div>
</div>

<!--  Modal submit -->
<div class="modal fade bs-example-modal-lg" tabindex="-1" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myLargeModalLabel">Expire Date</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div>
                    <div class="row">
                        <!-- <div class="col-md-6">
                        <label for="example-text-input" class=" col-form-label">Select Category</label>
                        <select name="" id="" class="form-select">
                                <option value="">Select</option>
                                <option value="">
                                    Baby Product</option>
                                <option value="">Bevarages</option>
                                <option value="">Canned Goods</option>
                                <option value="">Condiments</option>
                                <option value="">Cooking & Baking</option>
                                <option value="">Meat & Fish</option>
                                <option value="">Healthy & Beauty</option>
                                <option value="">Household & Cleaning</option>
                                <option value="">Pantry</option>
                                <option value="">Snacks</option>
                            </select>
                        </div> -->
                        <div class="col-md-12">
                            <label for="example-text-input" class=" col-form-label">Select Expire Date</label>
                            <input class="form-control mar-bottom-4" type="date">
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <div class="btn-group " role="group" aria-label="Basic example">
                        <a href="#" type="submit" class="btn btn-primary">Save</a>
                        <a href="#" type="button" class="btn btn-secondary">Cancel</a>
                    </div>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<!-- delete modal -->
<div class="modal fade bs-example-modal-lg2" tabindex="-1" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myLargeModalLabel">Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div>
                    <div class="row">
                        
                        <div class="col-md-12">
                            <h6>Are You Sure Want To Delete this?</h6>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <div class="btn-group " role="group" aria-label="Basic example">
                        <a href="#" type="submit" class="btn btn-primary">Save</a>
                        <a href="#" type="button" class="btn btn-secondary">Cancel</a>
                    </div>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>

<!-- end modal -->

<div class="modal fade bs-example-modal-lg3" tabindex="-1" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myLargeModalLabel">Select From Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive mb-0 ">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <ul class="ks-cboxtags justify-content-center">
                                                    <li>
                                                        <input type="checkbox" id="ba" value=""><label for="ba">
                                                        <img src="assets/images/baby-removebg-preview.png" alt="">    
                                                        Bevarages</label>
                                                    </li>
                                                </ul>
                                            </td>
                                            <td>
                                            <ul class="ks-cboxtags justify-content-center">
                                                    <li>
                                                        <input type="checkbox" id="bev" value=""><label for="bev">
                                                        <img src="assets/images/beverage-removebg-preview.png" alt="">     
                                                        Bevarages</label>
                                                    </li>
                                                </ul>
                                            </td>
                                            <td> 
                                            <ul class="ks-cboxtags justify-content-center">
                                                    <li>
                                                        <input type="checkbox" id="can" value=""><label for="can">
                                                        <img src="assets/images/canned-removebg-preview.png" alt="">    
                                                        Canned Goods</label>
                                                    </li>
                                                </ul>
                                            </td>
                                            <td>
                                                <ul class="ks-cboxtags justify-content-center">
                                                    <li>
                                                        <input type="checkbox" id="con" value=""><label for="con">
                                                        <img src="assets/images/cond-removebg-preview.png" alt="">    
                                                        Condiments</label>
                                                    </li>
                                                </ul>
                                            </td>

                                        </tr>
                                        <tr>
                                            
                                            <td> 
                                            <ul class="ks-cboxtags justify-content-center">
                                                    <li>
                                                        <input type="checkbox" id="coo" value=""><label for="coo">
                                                        <img src="assets/images/cook-removebg-preview.png" alt="">    
                                                        Cooking & Baking</label>
                                                    </li>
                                                </ul>
                                            </td>
                                            <td>
                                            <ul class="ks-cboxtags justify-content-center">
                                                    <li>
                                                        <input type="checkbox" id="mea" value=""><label for="mea">
                                                        <img src="assets/images/meat-removebg-preview.png" alt="">    
                                                        Meat & Fish</label>
                                                    </li>
                                                </ul>
                                            </td>
                                            <td>
                                                <ul class="ks-cboxtags justify-content-center">
                                                    <li>
                                                        <input type="checkbox" id="hea" value=""><label for="hea">
                                                        <img src="assets/images/health-removebg-preview.png" alt="">    
                                                        Health & Beauty</label>
                                                    </li>
                                                </ul>
                                            </td>

                                            <td> 
                                            <ul class="ks-cboxtags justify-content-center">
                                                    <li>
                                                        <input type="checkbox" id="hou" value=""><label for="hou">
                                                        <img src="assets/images/house-removebg-preview.png" alt="">    
                                                        Household & Cleaning</label>
                                                    </li>
                                                </ul>
                                            </td>

                                        </tr>
                                        <tr>
                                           
                                            <td>
                                            <ul class="ks-cboxtags justify-content-center">
                                                    <li>
                                                        <input type="checkbox" id="pan" value=""><label for="pan">
                                                        <img src="assets/images/pantry-removebg-preview.png" alt="">    
                                                        Pantry</label>
                                                    </li>
                                                </ul>
                                            </td>
                                            <td>
                                            <ul class="ks-cboxtags justify-content-center">
                                                    <li>
                                                        <input type="checkbox" id="sna" value=""><label for="sna">
                                                        <img src="assets/images/snack-removebg-preview.png" alt="">    
                                                        Snacks</label>
                                                    </li>
                                                </ul>
                                            </td>
                                            <td></td>
                                            <td></td>

                                        </tr>
                                       

                                    </tbody>
                                </table>
                            </div>
                            <!-- <ul class="ks-cboxtags justify-content-center">
                                <li>
                                    <input type="checkbox" id="all" value=""><label for="all">All Day</label>
                                </li>
                            </ul> -->
                        </div>
                    </div>

                </div>
               
            </div>
            <div class="modal-footer">
                    <div class="btn-group " role="group" aria-label="Basic example">
                        <a href="#" type="submit" class="btn btn-primary">Save</a>
                        <a href="#" type="button" class="btn btn-secondary">Cancel</a>

                    </div>
                </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>

<script>
    // Function that display value
    function dis(val) {
        document.getElementById("result").value += val
    }

    function myFunction(event) {
        if (event.key == '0' || event.key == '1' ||
            event.key == '2' || event.key == '3' ||
            event.key == '4' || event.key == '5' ||
            event.key == '6' || event.key == '7' ||
            event.key == '8' || event.key == '9' ||
            event.key == '+' || event.key == '-' ||
            event.key == '*' || event.key == '/')
            document.getElementById("result").value += event.key;
    }

    var cal = document.getElementById("calcu");
    cal.onkeyup = function(event) {
        if (event.keyCode === 13) {
            console.log("Enter");
            let x = document.getElementById("result").value
            console.log(x);
            solve();
        }
    }

    // Function that evaluates the digit and return result
    function solve() {
        let x = document.getElementById("result").value
        let y = math.evaluate(x)
        document.getElementById("result").value = y
    }

    // Function that clear the display
    function clr() {
        document.getElementById("result").value = ""
    }
</script>
<?php require_once('footer.php') ?>